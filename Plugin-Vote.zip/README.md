# Vote (Plugin)

[![Style](https://github.styleci.io/repos/237491397/shield)](https://github.styleci.io/repos/237491397)
[![Chat](https://img.shields.io/discord/625774284823986183?color=7289da&label=Discord&logo=discord&logoColor=fff&style=flat-square)](https://azuriom.com/discord)

A vote plugin to reward players when they vote.
